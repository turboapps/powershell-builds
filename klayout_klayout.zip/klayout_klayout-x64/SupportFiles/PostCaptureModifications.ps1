Write-Host "No post-capture changes required for KLayout."
